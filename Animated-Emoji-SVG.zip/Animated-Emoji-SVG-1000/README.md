# Emoji Vault — 1,000 premium-style animated SVGs

Exactly **1,000 distinct emoji SVG files**, organized into eight category folders. These are standalone, transparent, true-vector SVGs with newly authored premium-style motion.

**This is not an official Telegram Premium emoji pack.** The artwork is open-licensed Microsoft Fluent Emoji, and the animation is a recreated SVG adaptation. No Telegram Premium files were extracted.

## What's in the ZIP

- `emoji/` — exactly 1,000 animated `.svg` assets.
- `preview.html` — a fully offline, searchable gallery of all 1,000 assets. Preview, pause motion, inspect SVG code, and download or copy an individual SVG.
- `manifest.csv` — asset names, Unicode characters, categories, motion styles, file paths, sizes and checksums.
- `manifest.json` — the same information for code integration, plus source attribution.
- `licenses/` — artwork, animation/gallery, Unicode metadata and font license notices.
- `CREDITS.md` — sources and modification notes.

## Categories

| Folder | Collection | Count |
| --- | --- | ---: |
| `01-smileys-emotion` | Smileys & emotion | 168 |
| `02-people-gestures` | People & gestures | 100 |
| `03-animals-nature` | Animals & nature | 135 |
| `04-food-drink` | Food & drink | 110 |
| `05-travel-places` | Travel & places | 150 |
| `06-activities` | Activities | 75 |
| `07-objects` | Objects | 175 |
| `08-symbols-flags` | Symbols & flags | 87 |
| | **Total** | **1,000** |

No skin-tone variation sets or copied files were used to pad the count. Each asset has a different underlying vector artwork checksum.

## Use an emoji in your mini app

```html
<img
  src="./emoji/07-objects/money-bag.svg"
  alt="Money bag"
  width="48"
  height="48"
>
```

The animation lives inside the SVG. You do **not** need a GIF, video, Lottie runtime or JavaScript animation library to display an individual file. It also works in a normal web app or a Telegram Mini App webview that supports SVG SMIL.

You can change the display size with CSS or the image's `width` and `height`. The artwork scales as vectors. The default SVG canvas is 128 × 128, with a small transparent margin for motion.

Use `<img>` for repeated copies of an asset. If you inline several copies of the same SVG into one HTML document, give each copy unique IDs so its gradients and filters do not collide.

## Motion styles

12 loop styles: soft float, playful wiggle, heartbeat pulse, spring bounce, gentle sway, friendly wave, tiny flutter, cosmic drift, smooth spin, flame flicker, reward celebration and character nod.

Files add animated transforms, subtle shimmer, sparkles, or small celebration/ember effects where appropriate. They are **new motion treatments of still vector artwork**, not the original Telegram frame-by-frame animations. Each SVG includes a static fallback for the operating system's `prefers-reduced-motion` setting.

## Preview notes

1. Extract the ZIP.
2. Open **`preview.html`** in a modern browser.
3. Search by name, category, animation style, or emoji character.
4. Click an emoji to inspect and export it.

The gallery embeds every asset so it works offline. It is intentionally larger than a typical webpage. It displays only 40 items per page to keep playback manageable.

In an embedded/sandboxed file viewer, downloads or clipboard access may be blocked. Open the extracted gallery in your browser instead, or use the SVG files directly from their category folders.

Chrome, Firefox and Safari support the SMIL features used here. Image editors, Figma imports, server-generated thumbnails, or platforms that sanitize SVG may show a static frame instead of running the animation.

These browser SVGs are **not** directly uploadable as native Telegram custom emoji. Native Telegram emoji use other formats; this pack is intended as animated web assets.

## Permissions and attribution

- **Artwork:** Microsoft Fluent Emoji, MIT license. Every SVG retains the upstream MIT notice in its comment header; the full notice is also in `licenses/Fluent-Emoji-MIT.txt`.
- **Animation additions and gallery code:** MIT terms, in `licenses/MIT-Additions.txt`.
- **Unicode names/grouping:** Unicode Emoji 16.0 data, covered by the notice in `licenses/Unicode-LICENSE.txt`.
- **Gallery typography:** Inter, SIL Open Font License 1.1, in `licenses/Inter-OFL.txt`.

Keep the relevant notices with redistributed assets. No endorsement by Microsoft, Telegram or Iconify is implied. See `CREDITS.md` for exact source links.
