# Credits & provenance

## Vector artwork

- **Microsoft Fluent Emoji** — Microsoft Corporation.
- Original repository: https://github.com/microsoft/fluentui-emoji
- Original artwork license: https://github.com/microsoft/fluentui-emoji/blob/main/LICENSE
- SVG distribution used for this pack: Iconify's Fluent Emoji icon-set JSON.
- Distribution source: https://raw.githubusercontent.com/iconify/icon-sets/master/json/fluent-emoji.json
- Iconify collection repository: https://github.com/iconify/icon-sets
- Download/assembly date: 1 October 2026.

The upstream artwork license notice is retained in each SVG and in the licenses folder. The source dataset SHA-256 and individual geometry/file checksums are recorded in `manifest.json`.

## What was changed

- Selected exactly 1,000 distinct source artworks across eight collections, without using skin-tone variants to pad the count.
- Prefixed gradient/filter/mask IDs to keep different inline assets from colliding.
- Wrapped the original vector artwork in newly authored SVG SMIL animation.
- Added subtle sparkle, shimmer, confetti or ember effects where appropriate.
- Added a transparent motion margin and a static reduced-motion fallback.
- Added titles, descriptions, attribution metadata and a browsable offline gallery.

The motion is newly created; **it is not the original Microsoft animation or a Telegram Premium animation export**. The files are vectors with animation instructions, not videos or bitmaps hidden inside SVG wrappers.

## Emoji names and grouping

Unicode Emoji 16.0 test data:
https://www.unicode.org/Public/emoji/16.0/emoji-test.txt

License notice:
https://www.unicode.org/license.txt

A few legacy Fluent names are mapped to current CLDR names. The asset file names keep the Fluent identifiers so they remain easy to reference in code.

## Preview gallery font

Inter by Rasmus Andersson:
https://github.com/rsms/inter

License:
https://github.com/rsms/inter/blob/master/LICENSE.txt

The font is embedded only in the HTML gallery. Emoji files do not depend on fonts.

## No native Telegram assets

This pack is not associated with Telegram and does not contain their original Premium emoji, TGS animations or WebM files. It recreates a premium-style visual feel for browser-based mini apps using open-licensed vectors.
